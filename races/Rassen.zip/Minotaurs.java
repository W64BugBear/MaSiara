package races;

public class Minotaurs {

}
